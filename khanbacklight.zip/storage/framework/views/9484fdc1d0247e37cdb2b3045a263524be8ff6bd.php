  
<?php $__env->startSection('admin-content'); ?>
ggg
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>

<script>
    // function readURL1(input) {
    //     if (input.files && input.files[0]) {
    //         var reader = new FileReader();
            
    //         reader.onload = function (e) {
    //             $('#previewImage')
    //                 .attr('src', e.target.result)
    //                 .width(160)
    //                 .height(130);
    //         };

    //         reader.readAsDataURL(input.files[0]);
    //     }
    // }
    // document.getElementById("previewImage").src="<?php echo e(); ?>";
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/admin/factory.blade.php ENDPATH**/ ?>