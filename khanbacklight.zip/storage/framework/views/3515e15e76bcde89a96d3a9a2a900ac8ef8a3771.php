<section id="slider" class="slider">
    <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
        <div class="carousel-inner">
        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $count = 0 ?>
          <div class="carousel-item h-100 <?php echo e(($count == 0) ? 'active' : ''); ?>">
            <img src="<?php echo e(asset($item->image)); ?>" class="d-block w-100 h-100" alt="<?php echo e($item->slogan); ?>">
            <div class="carousel-caption d-none d-md-block">
                <h5><?php echo e($item->headerline); ?></h5>
                <p><?php echo e($item->description); ?></p>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
</section><?php /**PATH C:\xampp\htdocs\mehedi\believe store_2\resources\views/layouts/partials/web_slider.blade.php ENDPATH**/ ?>