
<?php $__env->startSection('web-content'); ?>

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
  <div class="container">

    <ol>
      <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li> Video </li>
    </ol>
    <h2>All Videos</h2>

  </div>
</section><!-- End Breadcrumbs -->

   <!-- ======= Video Section ======= -->
   <section id="video" class="video">

    <div class="container" data-aos="fade-up">
      <div class="row gy-4 portfolio-container" data-aos="fade-up" data-aos-delay="200">

        <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-6 portfolio-item filter-app">
          <h6 class="fw-bold text-center"><?php echo e($item->name); ?></h6>        
            <div class="">
              <iframe width="100%" height="150" src="<?php echo e($item->link); ?>" title="YouTube video" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
      </div>
    </div>
  </section>

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.website', ['pageName' => 'Video'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/website/video.blade.php ENDPATH**/ ?>