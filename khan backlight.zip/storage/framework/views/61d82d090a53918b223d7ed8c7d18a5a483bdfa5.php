

<?php $__env->startPush('admin-css'); ?>
<?php $__env->stopPush(); ?>    
<?php $__env->startSection('admin-content'); ?>
<main>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card my-3">
                    <div class="card-header">
                        <i class="fas fa-info-circle"></i>
                        Order Details
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Customer Information</h6>
                                <table class="table table-bordered" width="100%" cellspacing="0">
                                    <tbody>
                                        <tr>
                                          <th scope="row">Name</th>
                                          <td><?php echo e($orderCustomer->customer->name); ?></td>
                                        </tr>
                                        <tr>
                                          <th scope="row">Phone</th>
                                          <td><?php echo e($orderCustomer->customer->phone); ?></td>
                                        </tr>
                                        <tr>
                                          <th scope="row">Email</th>
                                          <td><?php echo e($orderCustomer->customer->email); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Address</th>
                                            <td><?php echo e($orderCustomer->customer->address); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <h6>Order Information</h6>
                                <table class="table table-bordered" width="100%" cellspacing="0">
                                    <tbody>
                                        <tr>
                                          <th scope="row">Invoice No</th>
                                          <td><?php echo e($orders->invoice_number); ?></td>
                                        </tr>
                                        <tr>
                                          <th scope="row">Total Amount</th>
                                          <td><?php echo e($orders->total_taka); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Order Date</th>
                                            <td><?php echo e(date('F j, Y', strtotime($orders->created_at))); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="card my-3">
            <div class="card-header">
                <i class="fas fa-list"></i>
                Products
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Product Name</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Sub Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php $__empty_1 = true; $__currentLoopData = $orders->orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td>
                                        <?php 
                                            $product = \App\Models\Product::where('id', $item->product_id)->first();
                                            if(isset($product))
                                            {
                                                $lastName = $product->name;
                                            }
                                            else {
                                                $lastName = 'Product Deleted';
                                            }
                                        ?>
                                        <?php echo e($lastName); ?>

                                    </td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td><?php echo e($item->price); ?></td>
                                    <td><?php echo e($item->total_taka); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6">Data Not Found</td>
                                </tr>
                            <?php endif; ?>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin-master', ['pageName'=> 'pending', 'title' => 'Invoice'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/admin/order/order-detail.blade.php ENDPATH**/ ?>