<!DOCTYPE html>
<html lang="en">
<!-- Mirrored from html.joomlastars.co.in/silla/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 03 Jul 2022 03:34:07 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Belive Store | Multi-Printing Function Shop</title>
<meta name="keywords" content="" />
<meta name="description" content="">
<meta name="author" content="">

<!-- Mobile view -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Favicon -->
<link rel="shortcut icon" href="<?php echo e(asset('website/images/favicon.ico')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/js/bootstrap/bootstrap.min.css')); ?>">

<!-- Google fonts  -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Yesteryear" rel="stylesheet">

<!-- Template's stylesheets -->
<link rel="stylesheet" href="<?php echo e(asset('website/js/megamenu/stylesheets/screen.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/theme-default.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('website/js/loaders/stylesheets/screen.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/css/corporate.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('website/css/shortcodes.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('website/fonts/font-awesome/css/font-awesome.min.css')); ?>" type="text/css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/fonts/Simple-Line-Icons-Webfont/simple-line-icons.css')); ?>" media="screen" />
<link rel="stylesheet" href="<?php echo e(asset('website/fonts/et-line-font/et-line-font.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/js/revolution-slider/css/settings.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/js/revolution-slider/css/layers.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/js/revolution-slider/css/navigation.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/js/parallax/main.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/js/cubeportfolio/cubeportfolio.min.css')); ?>">
<link href="<?php echo e(asset('website/js/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('website/js/owl-carousel/owl.theme.css')); ?>" rel="stylesheet">
<!-- Template's stylesheets END -->

<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<!-- Style Customizer's stylesheets -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/js/style-customizer/css/spectrum.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/js/style-customizer/css/style-customizer.css')); ?>">
<link rel="stylesheet/less" type="text/css" href="<?php echo e(asset('website/less/skin.html')); ?>">
<!-- Style Customizer's stylesheets END -->

<!-- Skin stylesheet -->
</head>

<body>



<!--end loading--> 

<!-- Style Customizer -->

<!-- Style customizer END -->

<div class="wrapper-boxed">
  <div class="site-wrapper">
    
    <?php echo $__env->make('layouts.partials.web_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--end menu-->
    <div class="clearfix"></div>
    
    <?php echo $__env->yieldContent('web-content'); ?>
    
    
    <?php echo $__env->make('layouts.partials.web_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  </div>
  <!--end site wrapper--> 
</div>
<!--end wrapper boxed--> 

<!-- Scripts --> 
<script src="<?php echo e(asset('website/js/jquery/jquery.js')); ?>"></script> 
<script src="<?php echo e(asset('website/js/bootstrap/bootstrap.min.js')); ?>"></script> 
<script src="<?php echo e(asset('website/js/style-customizer/js/spectrum.js')); ?>"></script> 
<script src="<?php echo e(asset('website/js/less/less.min.js')); ?>" data-env="development"></script>
<script src="<?php echo e(asset('website/js/style-customizer/js/style-customizer.js')); ?>"></script> 
<!-- Scripts END --> 

<!-- Template scripts --> 
<script src="<?php echo e(asset('website/js/megamenu/js/main.js')); ?>"></script> 


<!-- REVOLUTION JS FILES --> 
<script type="text/javascript" src="<?php echo e(asset('website/js/revolution-slider/js/jquery.themepunch.tools.min.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('website/js/revolution-slider/js/jquery.themepunch.revolution.min.js')); ?>"></script> 
<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  
(Load Extensions only on Local File Systems ! 
The following part can be removed on Server for On Demand Loading) --> 
<script type="text/javascript" src="<?php echo e(asset('website/js/revolution-slider/js/extensions/revolution.extension.actions.min.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('website/js/revolution-slider/js/extensions/revolution.extension.carousel.min.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('website/js/revolution-slider/js/extensions/revolution.extension.kenburn.min.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('website/js/revolution-slider/js/extensions/revolution.extension.layeranimation.min.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('website/js/revolution-slider/js/extensions/revolution.extension.migration.min.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('website/js/revolution-slider/js/extensions/revolution.extension.navigation.min.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('website/js/revolution-slider/js/extensions/revolution.extension.parallax.min.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('website/js/revolution-slider/js/extensions/revolution.extension.slideanims.min.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('website/js/revolution-slider/js/extensions/revolution.extension.video.min.js')); ?>"></script> 
<script src="<?php echo e(asset('website/js/parallax/parallax-background.min.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('website/js/cubeportfolio/jquery.cubeportfolio.min.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('website/js/cubeportfolio/main.js')); ?>"></script> 
<script src="<?php echo e(asset('website/js/owl-carousel/owl.carousel.js')); ?>"></script> 
<script src="<?php echo e(asset('website/js/owl-carousel/custom.js')); ?>"></script> 
<script src="<?php echo e(asset('website/js/functions/functions.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\mehedi\believe store_1\resources\views/layouts/website.blade.php ENDPATH**/ ?>