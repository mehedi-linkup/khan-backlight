<header>
  <nav class="navbar navbar-expand-lg fixed-top scrolling-navbar">
      <div class="container-lg">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
          <img src="<?php echo e(asset($content->logo)); ?>" alt="" >
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"><i class="fa-solid fa-bars"></i></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link <?php echo e(@($pageName == 'home')? 'active' : ''); ?> px-3 text-uppercase" aria-current="page" href="<?php echo e(route('home')); ?>#">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?php echo e(@($pageName == 'product')? 'active' : ''); ?> px-3 text-uppercase" href="<?php echo e(route('home')); ?>#category-menu">Product</a>
            </li>
            <li class="nav-item">
              <a class="nav-link px-3 text-uppercase" href="<?php echo e(route('home')); ?>#our-service">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link px-3 text-uppercase" href="<?php echo e(route('home')); ?>#team">Team</a>
            </li>
            <li class="nav-item">
              <a class="nav-link px-3 text-uppercase" href="<?php echo e(route('home')); ?>#gallery">Photos</a>
            </li>
            <li class="nav-item">
              <a class="nav-link px-3 text-uppercase" href="<?php echo e(route('home')); ?>#video-gallery">Videos</a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?php echo e(@($pageName == 'news')? 'active' : ''); ?> px-3 text-uppercase" href="<?php echo e(route('home')); ?>#news-event">News & Events</a>
            </li>
            
          </ul>
        </div>
      </div>
  </nav>
</header><?php /**PATH C:\xampp\htdocs\mehedi\believe store_2\resources\views/layouts/partials/web_header.blade.php ENDPATH**/ ?>