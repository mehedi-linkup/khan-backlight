



<?php $__env->startPush('admin-css'); ?>
    <link href="<?php echo e(asset('summernote/summernote-bs4.min.css')); ?>" rel="stylesheet">  
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin-content'); ?>


<main>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card my-3">
                    <div class="card-header">
                        <?php if(@isset($productData)): ?>
                        <i class="fas fa-edit mr-1"></i>Update Product
                        <?php else: ?>
                        <i class="fas fa-plus mr-1"></i>Add Product
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e((@$productData) ? route('admin.product.update', $productData->id) : route('admin.product.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            
                            <input type="hidden" name="old_image" value="<?php echo e(@$productData->image); ?>">
                            <div class="row">
                                <div class="col-md-7 mb-2">
                                    <label for="name" class="mb-2"> Product Name <span class="text-danger">*</span> </label>
                                    <input type="text" name="name" value="<?php echo e(@$productData->name); ?>" class="form-control form-control-sm mb-2" id="name" placeholder="Enter Product name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <label for="name" class="mb-2"> Product Description <span class="text-danger">*</span> </label>
                                    <textarea name="description" id="description" rows="4" class="form-control"><?php echo e(@$productData->description); ?></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-5 mb-2">

                                    <label for="product_id" class="mb-2"> Product Model </label>
                                    <input type="text" name="product_id" value="<?php echo e(@$productData->product_id); ?>" class="form-control form-control-sm mb-2" id="product_id" placeholder="Enter Product Model">
                                    <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <label for="about_image" class="mb-2">Product Image</label>
                                    <input class="form-control form-control-sm" id="image" type="file" name="image" onchange="mainThambUrl(this)">
                                    <div class="form-group mt-2">
                                        <img class="form-controlo img-thumbnail" src="<?php echo e((@$productData) ? asset($productData->image) : asset('uploads/no.png')); ?>" id="mainThmb" style="width: 150px;height: 120px;">
                                    </div>
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="clearfix border-top">
                                <div class="float-md-right mt-2">
                                    <button type="reset" class="btn btn-dark">Reset</button>
                                    <button type="submit" class="btn btn-info"><?php echo e((@$productData)?'Update':'Create'); ?></button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>

            </div>

        </div>

        <div class="row justify-content-center">

            <div class="col-md-12">
                <div class="card my-3">
                    <div class="card-header">
                        <i class="fas fa-list mr-1"></i>
                        Product List
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Product Name</th>
                                        <th>Model</th>
                                        <th>Image</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td><?php echo e($item->product_id); ?></td>
                                        <td><img src="<?php echo e(asset($item->image)); ?>" width="30" height="30" alt=""></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.product.edit', $item->id)); ?>" class="btn-sm btn btn-info"><i class="fas fa-edit"></i></a>
                                            <a href="<?php echo e(route('admin.product.delete', $item->id)); ?>" onclick="return confirm('Are you sure to Delete?')" class="btn-sm btn btn-danger"><i class="fas fa-trash"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('admin-js'); ?>
<script src="<?php echo e(asset('summernote/summernote-bs4.min.js')); ?>"></script>
<script>
    $('#description').summernote({
        tabsize: 2,
        height: 120
    });
</script>

<script>
    function mainThambUrl(input){
      if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function(e){
            $('#mainThmb').attr('src',e.target.result).width(150)
                  .height(120);
        };
        reader.readAsDataURL(input.files[0]);
      }
    }
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-master', ['pageName'=> 'product', 'title' => 'Add Product'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/admin/product.blade.php ENDPATH**/ ?>