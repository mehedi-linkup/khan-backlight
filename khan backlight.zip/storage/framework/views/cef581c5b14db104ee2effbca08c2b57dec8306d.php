<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                <a class="nav-link <?php echo e(($pageName == 'content' || $pageName == 'slide' || $pageName == 'backimage' || $pageName == 'news' || $pageName == 'category' || $pageName == 'subcategory' || $pageName == 'management' || $pageName == 'video' || $pageName == 'gallery' || $pageName == 'product' || $pageName == 'partner' || $pageName == 'whatcontent' ? 'active' : 'collapsed')); ?>" href="#" data-toggle="collapse" data-target="#collapseLayouts1" aria-expanded="false" aria-controls="collapseLayouts1">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Web Content
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse <?php echo e(($pageName == 'content' || $pageName == 'slider' || $pageName == 'backimage' || $pageName == 'news' || $pageName == 'category' || $pageName == 'subcategory' || $pageName == 'management' || $pageName == 'video' || $pageName == 'gallery' || $pageName == 'product' || $pageName == 'partner' || $pageName == 'whatcontent' ? 'show' : '')); ?>" id="collapseLayouts1" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('company.edit')); ?>">Company Content</a>
                        <a class="nav-link" href="<?php echo e(route('slider.index')); ?>">Slider</a>
                        <!-- <a class="nav-link" href="<?php echo e(route('whatwe.edit')); ?>">About Us</a> -->
                        <!-- <a class="nav-link" href="<?php echo e(route('backimage.edit')); ?>">Background Image</a> -->
                        <!-- <a class="nav-link" href="<?php echo e(route('service')); ?>">Service</a> -->
                        <!-- <a class="nav-link" href="<?php echo e(route('admin.categories')); ?>">Category</a> -->
                        <!-- <a class="nav-link" href="<?php echo e(route('admin.subcategories')); ?>">Subcategory</a> -->
                        <a class="nav-link" href="<?php echo e(route('admin.products')); ?>">Product</a>
                        <a class="nav-link" href="<?php echo e(route('service')); ?>">Our Speciality</a>
                        <a class="nav-link" href="<?php echo e(route('edit.factory')); ?>">Factory Information</a>
                        <a class="nav-link" href="<?php echo e(route('whatwe.edit')); ?>">History & Activity</a>
                        <a class="nav-link" href="<?php echo e(route('sister')); ?>">Sister Concern</a>
                        <a class="nav-link" href="<?php echo e(route('faq.index')); ?>">Faq</a>
                        <a class="nav-link" href="<?php echo e(route('galleries')); ?>">Gallery</a>
                        <a class="nav-link" href="<?php echo e(route('testimonial.index')); ?>">Testimonial</a>
                        <a class="nav-link" href="<?php echo e(route('management.index')); ?>">Management</a>
                        <a class="nav-link" href="<?php echo e(route('partner.index')); ?>">Client</a>
                        <a class="nav-link" href="<?php echo e(route('news')); ?>">News & Events</a>
                        <!-- <a class="nav-link" href="<?php echo e(route('videos')); ?>">Video</a> -->
                    </nav>
                </div>

                
                
                <a class="nav-link <?php echo e(($pageName == 'profile' || $pageName == 'register') ? 'active' : 'collapsed'); ?> " href="#" data-toggle="collapse" data-target="#collapseLayouts3" aria-expanded="false" aria-controls="collapseLayouts3">
                    <div class="sb-nav-link-icon"><i class="fas fa-users-cog"></i></div>
                    Authentication
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse <?php echo e(($pageName == 'profile' || $pageName == 'register') ? 'show' : ''); ?>" id="collapseLayouts3" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('register.create')); ?>">Add New User</a>
                        <a class="nav-link" href="<?php echo e(route('settings')); ?>">Update Profile</a>
                    </nav>
                </div>
                <a class="nav-link" href="<?php echo e(route('logout')); ?>">
                    <div class="sb-nav-link-icon"><i class="fa fa-power-off"></i></div>
                    Sign Out 
                </a>
            </div>
        </div>
    </nav>
</div><?php /**PATH C:\xampp\htdocs\mehedi\khan backlight\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>