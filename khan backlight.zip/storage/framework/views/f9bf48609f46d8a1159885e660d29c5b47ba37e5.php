<header id="header" class="header fixed-top">
  <div class="container-fluid container-xl d-flex align-items-center justify-content-between <?php echo e((\Request::route()->getName())=='home'? 'homeClass' : ''); ?>">

    <a href="<?php echo e(route('home')); ?>" class="logo d-flex align-items-center">
      <img src="<?php echo e(asset($content->logo)); ?>" alt="">
      <span>Backlight</span>
    </a>

    <nav id="navbar" class="navbar">
      <ul>
        <li><a class="nav-link scrollto" href="<?php echo e(route('home')); ?>#hero">Home</a></li>
        <li><a class="nav-link scrollto <?php echo e((@$pageName=='about')? 'active': ''); ?>" href="<?php echo e(route('about')); ?>">About</a></li>
        <li><a class="nav-link scrollto" href="<?php echo e(route('product')); ?>">Product</a></li>
        
        <li><a class="nav-link scrollto" href="<?php echo e(route('home')); ?>#features">Factory</a></li>
        
        <li><a class="nav-link scrollto" href="<?php echo e(route('faq')); ?>">FAQ</a></li>
        <li><a class="nav-link scrollto" href="<?php echo e(route('gallery')); ?>">Gallery</a></li>
        <li><a class="nav-link scrollto" href="<?php echo e(route('team')); ?>">Team</a></li>
        <li><a class="nav-link scrollto" href="<?php echo e(route('webnews')); ?>">News</a></li>
        <li><a class="nav-link scrollto" href="<?php echo e(route('home')); ?>#contact">Contact</a></li>
      </ul>
      <i class="bi bi-list mobile-nav-toggle"></i>
    </nav><!-- .navbar -->

  </div>
</header><!-- End Header --><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/layouts/partials/web_header.blade.php ENDPATH**/ ?>