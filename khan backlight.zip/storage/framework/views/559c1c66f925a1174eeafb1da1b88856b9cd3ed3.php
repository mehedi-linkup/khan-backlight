

<?php $__env->startSection('admin-content'); ?>

<main>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card my-3">
                    <div class="card-header">
                        <?php if(@isset($unitData)): ?>
                        <i class="fas fa-edit mr-1"></i>Update Unit
                        
                        <?php else: ?>
                        <i class="fas fa-plus mr-1"></i>Add Unit
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e((@$unitData) ? route('admin.unit.update', $unitData->id) : route('admin.unit.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12 mb-2">
                                    <label for="name"> Name <span class="text-danger">*</span> </label>
                                    <input type="text" name="name" value="<?php echo e(@$unitData->name); ?>" class="form-control form-control-sm mb-2" id="name" placeholder="Enter Unit Name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            
                            <div class="clearfix border-top">
                                <div class="float-md-right mt-2">
                                    <?php if(@$unitData): ?>
                                    <a href="<?php echo e(route('admin.unit')); ?>" class="btn btn-dark btn-sm">Back</a>
                                    <?php else: ?>
                                    <button type="reset" class="btn btn-dark btn-sm">Reset</button>
                                    <?php endif; ?>
                                    <button type="submit" class="btn btn-info btn-sm"><?php echo e((@$unitData)?'Update':'Create'); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>

            <div class="col-md-6">
                <div class="card my-3">
                    <div class="card-header">
                        <i class="fas fa-list mr-1"></i>
                        Unit List
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.unit.edit', $item->id)); ?>" class="btn btn-info btn-mod-info btn-sm"><i class="fas fa-edit"></i></a>
                                            <a href="<?php echo e(route('admin.unit.delete', $item->id)); ?>" onclick="return confirm('Are you sure to Delete?')" class="btn btn-danger btn-mod-danger btn-sm"><i class="fas fa-trash"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-master', ['pageName'=> 'unit', 'title' => 'Add Unit'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/admin/unit.blade.php ENDPATH**/ ?>