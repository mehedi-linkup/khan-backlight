<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
	<link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
</head>
<body>
	<form class="box" method="POST" action="<?php echo e(route('login')); ?>">
		<?php echo csrf_field(); ?>
        <h1>Login</h1>
        <input type="text" name="username" placeholder="username" required>
        <input type="password" name="password" placeholder="password" required>
        <input type="submit" value="Login">
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\mehedi\khan backlight\resources\views/auth/login.blade.php ENDPATH**/ ?>