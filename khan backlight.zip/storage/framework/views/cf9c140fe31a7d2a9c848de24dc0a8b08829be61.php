
<?php $__env->startPush('web-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/toastr.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('web-content'); ?>

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
  <div class="container">

    <ol>
      <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li> Order Placed </li>
    </ol>
    <div>
        <h2>Order Placed</h2>
    </div>

  </div>
</section><!-- End Breadcrumbs -->



<section id="cart" class="cart">
    <div class="container">
      <!-- Feature Tabs -->
      <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="text-center text-primary p-5">Yea! Your order placed successfully. We will contact with your very soon. Thank you.</h4>
                    <h5>Order Summery:</h5>
                    <table class="table table-bordered">
                        <thead>
                            <th>sl</th>
                            <th>Product Name</th>
                            <th>Product Image</th>
                            <th>Quantity</th>
                            <th>Total Taka</th>
                        </thead>
                        <?php $qty = 0; ?>
                        <tbody>
                            <?php $__currentLoopData = $details[0]->orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($item->product_id); ?></td>
                                    <td><?php echo e($item->product_id); ?></td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td><?php echo e($item->price); ?></td>
                                </tr>  
                                <?php $qty += $item->quantity; ?>                              
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="3">Total = </td>
                                <td><?php echo e($qty); ?></td>
                                <td><?php echo e($details[0]->total_taka); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer text-center">
                    <a class="btn btn-success" href="<?php echo e(route('home')); ?>">Back to Home</a>
                </div>
            </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('web-js'); ?>
  <script src="<?php echo e(asset('website/assets/vendor/jquery-3.6.0.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>

  <script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
  <script>
      <?php if(Session::has('success')): ?>
      toastr.options =
      {
          "closeButton" : true,
          "progressBar" : true
      }
      toastr.success("<?php echo e(session('success')); ?>");
      <?php endif; ?>
  
      <?php if(Session::has('error')): ?>
      toastr.options =
      {
          "closeButton" : true,
          "progressBar" : true
      }
              toastr.error("<?php echo e(session('error')); ?>");
      <?php endif; ?>
  </script>
<?php $__env->stopPush(); ?>
  
<?php echo $__env->make('layouts.website', ['pageName' => 'Order Placed'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/website/order-placed.blade.php ENDPATH**/ ?>