
<?php $__env->startSection('web-content'); ?>

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
  <div class="container">

    <ol>
      <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li> Faq </li>
    </ol>
    <h2>Frequently Asked Questions</h2>

  </div>
</section><!-- End Breadcrumbs -->

 <!-- ======= F.A.Q Section ======= -->
 <section id="faq" class="faq">

    <div class="container" data-aos="fade-up">
      <div class="accordion accordion-flush" id="faqlist1">
        <div class="row gy-2">
            <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6">
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-<?php echo e($item->id); ?>">
                    <?php echo e($item->name); ?>

                  </button>
                </h2>
                <div id="faq-content-<?php echo e($item->id); ?>" class="accordion-collapse collapse" data-bs-parent="#faqlist1">
                  <div class="accordion-body">
                    <?php echo e($item->details); ?>

                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>

    </div>

  </section><!-- End F.A.Q Section -->

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.website', ['pageName' => 'FAQ'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/website/faq.blade.php ENDPATH**/ ?>