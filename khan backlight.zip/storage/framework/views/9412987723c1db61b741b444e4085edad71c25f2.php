

<?php $__env->startSection('admin-content'); ?>
<main>
    
    <div class="container-fluid">
        <div class="card my-3">
            <div class="card-header">
                <i class="fas fa-list"></i>
                All Orders
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th class="text-left">Name</th>
                                <th>Phone</th>
                                <th class="text-left">Address</th>
                                <th class="text-left">Note</th>
                                <th>Invoice Number</th>
                                <th>Status</th>
                                <th class="text-right">Total Amount</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td class="text-left"><?php echo e($item->customer->name); ?></td>
                                    <td><?php echo e($item->customer->phone); ?></td>
                                    <td class="text-left"><?php echo e($item->customer->address); ?></td>
                                    <td class="text-left"><?php echo e($item->customer->note); ?></td>
                                    <td><?php echo e($item->invoice_number); ?></td>
                                    <td>
                                        
                                        <?php if($item->status == 'p' && !isset($item->deleted_at)): ?>
                                        <a href="<?php echo e(route('pending.state', $item->id)); ?>" class="btn btn-warning btn-mod-sm text-white">Pending</a>
                                        <?php elseif($item->status == 'c'&& !isset($item->deleted_at)): ?>
                                        <button type="button" class="btn btn-success btn-mod-sm text-white" disabled>Completed</button>
                                        <?php elseif($item->deleted_at): ?>
                                        <button type="button" class="btn btn-danger btn-mod-sm text-white" disabled>Cancelled</button>
                                        <?php else: ?>
                                        <a href="#!" class="btn btn-secondary btn-mod-sm text-white">No State</a>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-right"><?php echo e($item->total_taka); ?></td>
                                    <td>
                                        <?php if($item->deleted_at): ?>
                                        <a style="padding-left: 5px" href="<?php echo e(route('order.deleted', $item->id)); ?>" class="d-inline" onclick="return confirm('Are you sure you want to delete?');"><i class="fas fa-trash" style="color: red"></i></a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('order-details', $item->id)); ?>" class="d-inline" target="_blank"><i class="far fa-eye"></i></a>
                                        <a style="padding-left: 5px" href="<?php echo e(route('order.deleted', $item->id)); ?>" class="d-inline" onclick="return confirm('Are you sure you want to delete?');"><i class="fas fa-trash" style="color: red"></i></a>
                                        <?php endif; ?>
                                    </td>                          
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8">Data Not Found</td>
                                </tr>
                            <?php endif; ?>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', ['pageName'=> 'all', 'title' => 'All Orders'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/admin/order/all.blade.php ENDPATH**/ ?>