

<?php $__env->startSection('admin-content'); ?>

<main>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card my-3">
                    <div class="card-header">
                        <?php if(@isset($categoryData)): ?>
                        <i class="fas fa-edit mr-1"></i>Update Category
                        
                        <?php else: ?>
                        <i class="fas fa-plus mr-1"></i>Add Category (At most 8 category)
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e((@$categoryData) ? route('admin.category.update', $categoryData->id) : route('admin.category.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            
                            <div class="row">
                                <div class="col-md-6 mb-2">
                                    <label for="name"> Name <span class="text-danger">*</span> </label>
                                    <input type="text" name="name" value="<?php echo e(@$categoryData->name); ?>" class="form-control form-control-sm mb-2" id="name" placeholder="Enter Category name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <label for="image"> Image <span style="font-size: 12px; font-weight: 400">(768px * 768px)</span> <span class="text-danger">*</span> </label>
                                    <input type="file" name="image" value="<?php echo e(@$categoryData->image); ?>" class="form-control form-control-sm" id="image" onchange="mainThambUrl(this)">
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="form-group mt-2">
                                        <img class="form-controlo img-thumbnail" src="<?php echo e((@$categoryData) ? asset($categoryData->image) : asset('uploads/no.png')); ?>" id="mainThmb" style="width: 150px;height: 120px;">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="clearfix border-top">
                                <div class="float-md-right mt-2">
                                    <button type="reset" class="btn btn-dark btn-sm">Reset</button>
                                    <button type="submit" class="btn btn-info btn-sm"><?php echo e((@$categoryData)?'Update':'Create'); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>

            <div class="col-md-12">
                <div class="card my-3">
                    <div class="card-header">
                        <i class="fas fa-list mr-1"></i>
                        Category List
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Image</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <?php if($item->image): ?>
                                        <td><img src="<?php echo e(asset($item->image)); ?>" alt="" style="height: 60px; width: 60px"></td>
                                        <?php else: ?>
                                        <td><img src="<?php echo e(asset('uploads/no.png')); ?>" alt="" style="height: 60px; width: 60px"></td>
                                        <?php endif; ?>
                                        <td>
                                            <a href="<?php echo e(route('admin.category.edit', $item->id)); ?>" class="btn btn-info btn-mod-info btn-sm"><i class="fas fa-edit"></i></a>
                                            <a href="<?php echo e(route('admin.category.delete', $item->id)); ?>" onclick="return confirm('Are you sure to Delete?')" class="btn btn-danger btn-mod-danger btn-sm"><i class="fas fa-trash"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
<script>
    function mainThambUrl(input){
      if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function(e){
            $('#mainThmb').attr('src',e.target.result).width(150)
                  .height(120);
        };
        reader.readAsDataURL(input.files[0]);
      }
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-master', ['pageName'=> 'category', 'title' => 'Add Category'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/admin/categories.blade.php ENDPATH**/ ?>