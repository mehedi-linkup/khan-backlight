
<?php $__env->startSection('web-content'); ?>
<?php $__env->startPush('web-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/toastr.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/assets/vendor/owl-carousel/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('website/assets/vendor/owl-carousel/owl.theme.default.min.css')); ?>">
<?php $__env->stopPush(); ?>

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
  <div class="container">

    <ol>
      <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li> Product </li>
    </ol>
    <h2>Our Products</h2>

  </div>
</section><!-- End Breadcrumbs -->


<section class="search" style="padding-top: 10px; padding-bottom: 0">
  <div class="container" data-aos="fade-down">
    <div class="row">
      <div class="col-lg-12 d-flex justify-content-end">
        
        <div class="search-box">
          <form action="<?php echo e(route('search')); ?>" method="GET">
            <div class="">
              <input type="search" name="q" class="form-control form-control-sm serach-control search-box keyword" id="keyword" autocomplete="off" placeholder="search...">
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ======= Product Section ======= -->
<section id="products" class="products" style="padding-top: 30px">
  <div class="container" data-aos="fade-up">
    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($item1->product && count($item1->product) > 0): ?>
    <div class="row">
      <div class="col-lg-12">
        <div class="product-header mb-1 clearfix" style="border-bottom: 1px solid #c5c5c5;">
          <span class="fw-bold text-uppercase"><?php echo e($item1->name); ?></span>
          <a href="<?php echo e(route('cat-product', $item1->id)); ?>" class="float-end btn btn-see-more btn-danger">See More</span></a>
        </div>
      </div>
      <div class="col-lg-12" data-aos="fade-up" data-aos-delay="600">
        <div class="owl-carousel owl-theme">
          <?php $__currentLoopData = $item1->product->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="item">
            <div class="card p-2 p-lg-3" style="position: relative">
              <a href="<?php echo e(route('product-detail', $item->id)); ?>" style="position: absolute; top:0; bottom:0; left:0; right:0; z-index: 1"></a>
              <div class="img-box">
                <img width="100%" src="<?php echo e(asset($item->image)); ?>" class="card-img-top" alt="Avenue Montaigne">
              </div>
              <div class="card-body p_card text-start">
                <h5 class="card-title"><?php echo e($item->name); ?></h5>
                <p style="font-size: 13px; margin-top: 4px; margin-bottom: 2px;"><span style="color: #333; font-weight: 700;">Model &nbsp;</span><span class="text-danger"><?php echo e($item->model->name); ?></span></p>
                <p class="mb-0" style="color: #333; font-weight: 700; font-size: 14px;">TK <?php echo e($item->rate); ?></p>
              </div>
              <div class="product-cart">
                <form action="<?php echo e(route('cart.store')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                  <input type="hidden" name="quantity" value="1">
                  <button type="submit" class="btn btn-sm w-100"><i class="bi bi-cart4"></i> Add to cart</button>
                </form>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</section><!-- End Product Section -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('web-js'); ?>
<script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('website/assets/vendor/bootstrap3-typeahead.min.js')); ?>" ></script>
<script type="text/javascript">
  var baseUri = "<?php echo e(url('/')); ?>";
  $('.keyword').typeahead({
      minLength: 1,
      source: function (keyword, process) {
          return $.get(`${baseUri}/get_suggestions/${keyword}`, function (data) {
              return process(data);
          });
      },
      updater:function (item) {
          $(location).attr('href', '/search?q='+item);
          return item;
      }
  });
</script>
<script src="<?php echo e(asset('website/assets/vendor/owl-carousel/owl.carousel.min.js')); ?>"></script>
<script>
  $('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    // autoplay:true,
    // autoplayTimeout:1000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})
</script>
<script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
<script>
    <?php if(Session::has('success')): ?>
    toastr.options =
    {
        "closeButton" : true,
        "progressBar" : true
    }
    toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
    toastr.options =
    {
        "closeButton" : true,
        "progressBar" : true
    }
            toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>
</script>
<?php $__env->stopPush(); ?>
  
<?php echo $__env->make('layouts.website', ['pageName' => 'Product'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/website/product.blade.php ENDPATH**/ ?>