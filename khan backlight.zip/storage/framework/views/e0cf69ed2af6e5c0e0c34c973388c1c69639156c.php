
<?php $__env->startSection('web-content'); ?>

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
  <div class="container">

    <ol>
      <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li> Product </li>
    </ol>
    <h2>Our Products</h2>

  </div>
</section><!-- End Breadcrumbs -->


    <!-- ======= Product Section ======= -->
    <section id="products" class="products">

      <div class="container" data-aos="fade-up">
        <div class="row row-cols-1 row-cols-lg-5 gy-3">
          <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col" data-aos="fade-up" data-aos-delay="600">
            <div class="card p-2 p-lg-3">
              <div class="img-box">
                  <a href="<?php echo e(route('product-detail', $item->id)); ?>">
                      <img width="100%" height="219" src="<?php echo e(asset($item->image)); ?>" class="card-img-top" alt="Avenue Montaigne">
                  </a>
              </div>
              <div class="card-body p_card text-center">
                  <a href="<?php echo e(route('product-detail', $item->id)); ?>">
                      <h5 class="card-title"><?php echo e($item->name); ?></h5>
                  </a> 
                  <div class="product-id pb-md-2"> <?php echo e($item->product_id); ?></div>
                  <div class="">
                      <a href="<?php echo e(route('order', $item->id)); ?>" class="btn button-2 btn-card">Order Now</a>
                  </div>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section><!-- End Product Section -->

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.website', ['pageName' => 'product'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/website/product.blade.php ENDPATH**/ ?>