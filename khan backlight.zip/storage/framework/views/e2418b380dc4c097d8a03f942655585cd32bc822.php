

<?php $__env->startSection('web-content'); ?>

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
    <div class="container">

      <ol>
        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li> About </li>
      </ol>
      <h2>About Us</h2>

    </div>
  </section><!-- End Breadcrumbs -->

  <section id="about" class="about">
    <div class="container" data-aos="fade-up">
      <div class="row gx-0">

        <div class="col-lg-12" data-aos="fade-up" data-aos-delay="200">
          <div class="content ">
            <h3>Who We Are</h3>
            <div class="clearfix">
              <img src="<?php echo e(asset($content->about_image)); ?>" class="img-fluid about-section-img float-md-end ps-md-3 pt-md-2" alt=""> 
              <div class="m-0" style="text-align: justify">
                <?php echo $content->about; ?>

              </div>
            </div>
          </div>
        </div>

        
      </div>
    </div>
</section><!-- End About Section -->

</main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', ['pageName' => 'about'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/website/about.blade.php ENDPATH**/ ?>