
<?php $__env->startSection('web-content'); ?>

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
  <div class="container">
    <ol>
      <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li><a href="<?php echo e(route('gallery')); ?>">Events</a></li>
      <li> <?php echo e($event->name); ?> </li>
    </ol>
    <h2>Our <?php echo e($event->name); ?>Photos</h2>
  </div>
</section><!-- End Breadcrumbs -->
<!-- ======= Portfolio Section ======= -->
<section id="portfolio" class="portfolio">
    <div class="container" data-aos="fade-up">
        <div class="row gy-4">
            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 portfolio-item filter-app">
                <div class="portfolio-wrap">
                <img src="<?php echo e(asset('uploads/gallery/'.$item->image)); ?>" class="img-fluid" alt="">
                <div class="portfolio-info">
                    <h4><?php echo e($item->title); ?></h4>
                    <div class="portfolio-links">
                    <a href="<?php echo e(asset('uploads/gallery/'.$item->image)); ?>" data-gallery="portfolioGallery" class="portfokio-lightbox" title="<?php echo e($item->title); ?>"><i class="bi bi-plus"></i></a>
                    </div>
                </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section><!-- End Portfolio Section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', ['pageName' => 'Gallery'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/website/event-gallery.blade.php ENDPATH**/ ?>