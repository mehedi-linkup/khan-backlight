
<?php $__env->startSection('web-content'); ?>

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
  <div class="container">

    <ol>
      <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li> Activity </li>
    </ol>
    <h2>Our Activity</h2>

  </div>
</section><!-- End Breadcrumbs -->


<section id="history" class="history">
    <div class="container" data-aos="fade-up">
      <!-- Feature Tabs -->
      <div class="row history-tabs" data-aos="fade-up">
        <div class="col-lg-12">
          <img src="<?php echo e(asset($activity->image)); ?>" class="img-fluid ms-lg-5 border border-3 custom-border float-end" style="width: 45%" alt="">
          <h3>Activities of Our Company</h3>
          <!-- Tabs -->
          <!-- Tab Content -->
          <div class="tab-content">

            <div class="tab-pane fade show active" id="tab1">
              <?php echo $activity->description2; ?>

            </div><!-- End Tab 1 Content -->
          </div>
        </div>

      </div>
    </div>
  </section>

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/website/activity.blade.php ENDPATH**/ ?>