
<?php $__env->startSection('web-content'); ?>
<section id="product-background" class="product-background d-flex" style="background-image: url('<?php echo e(asset('/website/assets/image/section-background/'.$backimage->bgimage_other)); ?>')">
    <div class="container align-self-center">
        <div class="row">
            <div class="col-lg-6 offset-lg-3 col-12">
                <nav aria-label="breadcrumb" style="--bs-breadcrumb-divider: '';">
                    <ol class="breadcrumb justify-content-center">
                      <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home </a></li>
                      <span>&nbsp;/&nbsp;</span>
                      <li class="breadcrumb-item active" aria-current="page"> <?php echo e($category->name); ?></li>
                    </ol>
                  </nav>
            </div>
        </div>
    </div>
</section>

<section id="category-menu" class="category-menu section-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-12">
          <h2 class="section-title fs-2 fw-bold text-center text-uppercase text-white"><?php echo e($category->name); ?></h2>
        </div>
      </div>
      <div class="row gy-3">
        <?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 col-12 text-center">
          <a href="<?php echo e(route('product', $item->id)); ?>" class="filter-anchor">
            <div class="filter-box">
              <div class="img-box">
                <img src="<?php echo e(asset('uploads/subcategory/'. $item->image)); ?>" alt="<?php echo e($item->name); ?>" class="img-fluid">
              </div>
              <h5 class="product-title mt-2"><?php echo e(Str::limit($item->name, 25, '')); ?></h5>
            </div>
          </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </section>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', ['pageName' => 'product'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mehedi\believe store_2\resources\views/pages/website/submenu.blade.php ENDPATH**/ ?>