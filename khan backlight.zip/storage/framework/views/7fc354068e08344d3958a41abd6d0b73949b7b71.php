
<?php $__env->startSection('web-content'); ?>

<?php echo $__env->make('layouts.partials.web_slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="category-menu" class="category-menu section-padding">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-12">
        <h2 class="fs-2 fw-bold text-center text-uppercase text-white"><span class="section-border">Our Product List</span></h2>
      </div>
    </div>
    <div class="row gy-3">
      <?php $__currentLoopData = $category->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-3 col-12 text-center">
        <a href="<?php echo e(route('submenu', $item->id)); ?>" class="filter-anchor">
          <div class="filter-box">
            <div class="img-box">
              <img src="<?php echo e(asset( $item->image )); ?>" alt="<?php echo e($item->name); ?>" class="img-fluid"/>
            </div>
            <h5 class="product-title mt-2"><?php echo e(Str::limit($item->name, 25, '')); ?></h5>
          </div>
        </a>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>

<section id="our-service" class="our-service section-light section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-12">
                <img src="<?php echo e(asset( $content->about_image )); ?>" alt="" class="w-100">
            </div>
            <div class="col-md-4 col-12">
                <img src="<?php echo e(asset( $content->bg_image )); ?>" alt="" class="w-100">
            </div>
            <div class="col-md-4 col-12">
                <div class="custom-card">
                    <h2 class="welcome-title fs-3 fw-bold text-uppercase">Welcome To <?php if(isset($content->name)): ?>
                      <?php echo e($content->name); ?>

                    <?php endif; ?>
                  </h2>
                    
                    <div class="description"><?php echo $content->about; ?></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="what-we-do" class="what-we-do section-padding">
    <div class="container">
        <div class="row">
          <div class="col-md-6 col-12">
              <div class="grand-box">
                <div class="inner-box">
                  <h3 class="card-title text-uppercase fw-bold mb-3">Who we are</h3>
                  <!-- <p class="card-semi-text w-75 mb-4">Pellentesque ut risus a odio posuere aliquet Pellentesque sapien erat .</p> -->
                  <!-- <ul class="mb-5">
                    <li><i class="fa-solid fa-circle-arrow-right"></i> <span>Sed massa tellus, aliquam rhoncus, venenatis quis.</span></li>
                    <li><i class="fa-solid fa-circle-arrow-right"></i> <span>enim. Suspendisse imperdiet cursus nisi.</span></li>
                  </ul> -->
                  <!-- <a href="" class="btn btn-orange text-uppercase rounded-pill">Read More</a> -->
                  <div>
                    <?php echo $whatwe->description1; ?>

                  </div>
                </div>
              </div>
          </div>
            <div class="col-md-6 col-12">
              <div class="grand-box">
                <div class="inner-box">
                  <h3 class="card-title text-uppercase fw-bold mb-3">WHAT WE DO</h3>
                  <!-- <p class="card-semi-text w-75 mb-4">Pellentesque ut risus a odio posuere aliquet Pellentesque sapien erat .</p>
                  <ul class="mb-5">
                    <li><i class="fa-solid fa-circle-arrow-right"></i> <span>Sed massa tellus, aliquam rhoncus, venenatis quis.</span></li>
                    <li><i class="fa-solid fa-circle-arrow-right"></i> <span>Etiam enim. Suspendisse imperdiet cursus nisi.</span></li>
                  </ul> -->
                  <!-- <a href="" class="btn btn-orange text-uppercase rounded-pill">Read More</a> -->
                  <div>
                    <?php echo $whatwe->description2; ?>

                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
</section>

<section id="our-passion" class="our-passion">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-6 col-12 ps-0 d-none d-md-block">
        <img src="<?php echo e(asset($whatwe->image)); ?>" alt="" class="img-fluid p-md-5 bg-white h-100">
      </div>
      <div class="col-md-6 col-12 pe-md-0 d-flex">
        <div class="text-box align-self-center">
          <h3 class="card-title text-uppercase text-danger mb-1">It's our passion</h3>
          <h3 class="card-title text-uppercase fw-bold mb-4"><?php echo e($whatwe->title3); ?></h3>
          <!-- <h6 class="card-semi-text w-75 mb-3">Suspendisse et justo. Praesent mattis commodo augue Aliquam ornare hendrerit augue.</h6>
          <p class="card-semi-text w-75 mb-4">Whether it’s checking the ‘gram, taking selfies or replying to those all-important group chats, we know your phone is never far from your hand! Turn your phone into a work of art. Browse our complete range of designer phone cases featuring original designs</p>
          <ul class="mb-5">
            <li><i class="fa-solid fa-circle-arrow-right"></i> <span>Nullam efficitur velit ut interdum pellentesque.</span></li>
            <li><i class="fa-solid fa-circle-arrow-right"></i> <span>Maecenas sit amet orci eget mi commodo scelerisque eu tempus mi.</span></li>
            <li><i class="fa-solid fa-circle-arrow-right"></i> <span>Vivamus at sem rhoncus, posuere elit id, semper ipsum.</span></li>
          </ul>
          <a href="" class="btn btn-black text-uppercase rounded-pill">Read More</a> -->
          <div>
            <?php echo $whatwe->description3; ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section id="team" class="our-team section-padding">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-12">
        <h2 class="fs-2 fw-bold text-center text-uppercase text-white"><span class="section-border">Meet our Team</span></h2>
      </div>
    </div>
    <div class="row">
      <?php $__currentLoopData = $management->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-3 col-12">
        <div class="team-box">
          <div class="img-box">
            <div class="icon-box">
              <ul class="link-icons justify-content-around">
                <li><a href="<?php echo e($item->facebook); ?>" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                <li><a href="<?php echo e($item->twitter); ?>" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                <li><a href="<?php echo e($item->instagram); ?>" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                
              </ul>
            </div>
            <img src="<?php echo e(asset('uploads/management/'.$item->image)); ?>" alt="<?php echo e($item->name); ?>" class="img-fluid">
          </div>
          <h5 class="product-title text-center mt-4"><?php echo e($item->name); ?></h5>
          <p class="text-designation text-center"><?php echo e($item->designation); ?></p>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>

<section id="gallery" class="our-gallery section-padding">
  <div class="container">
    <div class="row">
      <h2 class="fs-2 fw-bold text-center text-uppercase"><span class="section-border-black">Our Gallery</span></h2>
    </div>
    <div class="row">
      <ul class="gallery">
        <?php $__currentLoopData = $gallery->take(15); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
          <a href="<?php echo e(asset('uploads/gallery/'.$item->image )); ?>" title="<?php echo e($item->name); ?>" class="image-link">
            <img src="<?php echo e(asset('uploads/gallery/'.$item->image )); ?>" alt="">
          </a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  </div>
</section>

<section id="video-gallery" class="video-gallery section-padding">
  <div class="container">
    <div class="row">
      <h2 class="fs-2 fw-bold text-center text-uppercase"><span class="section-border-black">Video Gallery</span></h2>
    </div>
    <div class="row">
     
      <div class="col-md-5 col-12">
        <div>
          <iframe width="100%" height="274" src="<?php echo e($video[0]->link); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
        </div>
      </div>
      
      <div class="col-md-7 col-12 mt-md-0 mt-2">
        <div class="row row-cols-md-3 row-cols-2 gx-1">
         <?php for($i = 1; $i < sizeof($video->take(7)); $i++): ?>
          <div class="col">
            <iframe width="100%" height="135" src="<?php echo e($video[$i]->link); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
          </div>
          <?php endfor; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<section id="news-event" class="news-event">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-8 col-12 ps-md-5 pe-md-5 section-padding">
        <div class="row">
          <div class="col-md-12 col-12">
            <h2 class="fs-2 fw-bold text-center text-uppercase text-white"><span class="section-border">News & Events</span></h2>
          </div>
        </div>
        <div class="row gy-2 gy-md-0">
          <?php $__currentLoopData = $news->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
          $monthNum  = date('m', strtotime($item->created_at));
          $dateObj   = DateTime::createFromFormat('!m', $monthNum);
          $monthName = $dateObj->format('F'); 
          ?>
          <div class="col-md-6 col-12">
            <div class="full-box" style="height: 100%">
              <div class="image-card">
                <div class="post-date-box"> <?php echo e(date('d', strtotime($item->created_at))); ?> <span><?php echo e($monthName); ?>, <?php echo e(date('y', strtotime($item->created_at))); ?></span></div>
                <img src="<?php echo e(asset($item->image)); ?>" alt="" class="img-fluid">
              </div>
              <div class="text-box">
                <h4><a href="<?php echo e(route('newsDetail', $item->id)); ?>"><?php echo e($item->title); ?></a></h4>
                <p><?php echo e(Str::words($item->description, 15, '')); ?></p>
              </div>
            </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <div class="col-md-4 col-12 pe-0 d-none d-md-block">
        <img src="<?php echo e(asset('website/assets/image/section-background/'.$backimage->bgimage_news)); ?>" alt="" class="cover-img w-100 h-100">
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', ['pageName' => 'home'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mehedi\believe store_2\resources\views/pages/website/index.blade.php ENDPATH**/ ?>