<div class="col-md-12 nopadding">
    <div class="header-section style1 noborder pin-style">
      <div class="container">
        <div class="mod-menu">
          <div class="row">
            <div class="col-sm-2"> <a href="<?php echo e(route('home')); ?>" title="" class="logo style-2 mar-2"> <img src="<?php echo e(asset('website/images/logo/logo-removebg-preview.png')); ?>" alt="" style="height: 67px; width: 90px"> </a> </div>
            <div class="col-sm-10">
              <div class="main-nav">
                <ul class="nav navbar-nav top-nav">
                  <li class="search-parent"> <a href="javascript:void(0)" title=""><i aria-hidden="true" class="fa fa-search"></i></a>
                    <div class="search-box ">
                      <div class="content">
                        <div class="form-control">
                          <input type="text" placeholder="Type to search" />
                          <a href="#" class="search-btn mar-1"><i aria-hidden="true" class="fa fa-search"></i></a> </div>
                        <a href="#" class="close-btn mar-1">x</a> </div>
                    </div>
                  </li>
                  
                  <li class="visible-xs menu-icon"> <a href="javascript:void(0)" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#menu" aria-expanded="false"> <i aria-hidden="true" class="fa fa-bars"></i> </a> </li>
                </ul>
                <div id="menu" class="collapse">
                  <ul class="nav navbar-nav">
                    <li class="right active"> <a href="<?php echo e(route('home')); ?>">Home</a> <span class="arrow"></span>
                      <ul class="dm-align-2">
                        
                        
                      </ul>
                    </li>
                    
                    <li> <a href="slider-kenburns.html">Features</a> <span class="arrow"></span>
                      <ul class="dm-align-2">
                        <li> <a href="#">Sliders <span class="sub-arrow dark pull-right"><i class="fa fa-angle-right" aria-hidden="true"></i></span> </a> <span class="arrow"></span>
                          <ul>
                            <li> <a href="slider-kenburns.html">KenBurns</a> </li>
                            
                          </ul>
                        </li>
                        
                        
                        
                        
                        
                      </ul>
                    </li>
                    <li class="mega-menu"> <a href="header-style3.html">Portfolio</a> <span class="arrow"></span>
                      <ul>
                        <li> <a href="#" title="home samples">Portfolio columns</a> <span class="arrow"></span>
                          <ul>
                            <li> <a href="portfolio-1-columns.html"><i class="fa fa-angle-right"></i> &nbsp; One Column</a> </li>
                            
                          </ul>
                        </li>
                        
                      </ul>
                    </li>
                    
                    
                    
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--end menu--> 
    
  </div><?php /**PATH C:\xampp\htdocs\mehedi\believe store_1\resources\views/layouts/partials/web_header.blade.php ENDPATH**/ ?>