
<?php $__env->startSection('web-content'); ?>

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
  <div class="container">

    <ol>
      <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li> Team </li>
    </ol>
    <h2>Our Team</h2>

  </div>
</section><!-- End Breadcrumbs -->

   <!-- ======= Team Section ======= -->
   <section id="team" class="team">

    <div class="container" data-aos="fade-up">

      <div class="row gy-4">

        <?php $__currentLoopData = $management; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="member">
              <div class="member-img">
                <img src="<?php echo e(asset('uploads/management/'. $item->image)); ?>" class="img-fluid" alt="">
                <div class="social">
                  <a href="<?php echo e($item->twitter); ?>" target="_blank"><i class="bi bi-twitter"></i></a>
                  <a href="<?php echo e($item->facebook); ?>" target="_blank"><i class="bi bi-facebook"></i></a>
                  <a href="<?php echo e($item->instagram); ?>" target="_blank"><i class="bi bi-instagram"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4><?php echo e($item->name); ?></h4>
                <span><?php echo e($item->designation); ?></span>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

    </div>

  </section><!-- End Team Section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/website/team.blade.php ENDPATH**/ ?>