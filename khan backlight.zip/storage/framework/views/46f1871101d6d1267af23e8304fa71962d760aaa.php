
<?php $__env->startSection('web-content'); ?>
<?php $__env->startPush('web-css'); ?>
<?php $__env->stopPush(); ?>

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
  <div class="container">

    <ol>
      <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li> product  </li>
      <li> <?php echo e($category->name); ?> </li>
    </ol>
    <h2>All Product of <?php echo e($category->name); ?></h2>

  </div>
</section><!-- End Breadcrumbs -->
<!-- ======= Category with Product Section ======= -->
 
<section id="products" class="products">
    <div class="container" data-aos="fade-up">
      <div class="row row-cols-1 row-cols-lg-5 gy-3">
        <div class="col-lg-12">
          <div class="product-header mb-1 clearfix" style="border-bottom: 1px solid #c5c5c5;">
            <span class="fw-bold text-uppercase"><?php echo e($category->name); ?></span>
          </div>
        </div>
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col" data-aos="fade-up" data-aos-delay="600">
          <div class="card p-2 p-lg-3" style="position: relative">
            <a href="<?php echo e(route('product-detail', $item->id)); ?>" style="position: absolute; top:0; bottom:0; left:0; right:0; z-index: 1"></a>
            <div class="img-box">
              <img width="100%" src="<?php echo e(asset($item->image)); ?>" class="card-img-top" alt="Avenue Montaigne">
            </div>
            <div class="card-body p_card text-start">
              <h5 class="card-title"><?php echo e($item->name); ?></h5>
              <p style="font-size: 13px; margin-top: 4px; margin-bottom: 2px;"><span style="color: #333; font-weight: 700;">Model &nbsp;</span><span class="text-danger"><?php echo e($item->model->name); ?></span></p>
              <p class="mb-0" style="color: #333; font-weight: 700; font-size: 14px;">TK <?php echo e($item->rate); ?></p>
            </div>
            <div class="product-cart">
              <form action="<?php echo e(route('cart.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                <input type="hidden" name="quantity" value="1">
                <button type="submit" class="btn btn-sm w-100">Add to cart <i class="bi bi-cart4"></i></button>
              </form>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </section><!-- End Product Section -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('web-js'); ?>
<script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
<script>
    <?php if(Session::has('success')): ?>
    toastr.options =
    {
        "closeButton" : true,
        "progressBar" : true
    }
    toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
    toastr.options =
    {
        "closeButton" : true,
        "progressBar" : true
    }
            toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>
</script>
<?php $__env->stopPush(); ?>
  
<?php echo $__env->make('layouts.website', ['pageName' => 'Products with category'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/website/cat-product.blade.php ENDPATH**/ ?>