	
<?php $__env->startSection('web-content'); ?>

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
	<div class="container">
  
	  <ol>
		<li><a href="<?php echo e(route('home')); ?>">Home</a></li>
		<li> News Title </li>
	  </ol>
	  <h2><?php echo e($news->title); ?></h2>
  
	</div>
  </section><!-- End Breadcrumbs -->

<section id="news-details" class="news-details section-padding">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-12">
				<h2 class="fs-2 fw-bold text-center text-uppercase text-white"><span class="section-border">News & Events</span></h2>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6 col-12">
				<div class="img-box">
					<img src="<?php echo e(asset($news->image)); ?>" alt="" class="img-fluid">
				</div>
			</div>
			<div class="col-md-6 col-12">
				<div class="details-box">
					<div class="date float-end" style="text-decoration: underline"><?php echo e(date('F j, Y', strtotime($news->created_at))); ?></div>
					<h4><?php echo e($news->title); ?></h4>
					<p style="text-align: justify"><strong>Description: </strong><?php echo e($news->description); ?></p>
				</div>
			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.website', ['pageName' => 'news'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/website/news-details.blade.php ENDPATH**/ ?>