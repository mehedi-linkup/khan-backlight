
<?php $__env->startSection('web-content'); ?>

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
  <div class="container">

    <ol>
      <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li> Events </li>
    </ol>
    <h2>Our Events</h2>

  </div>
</section><!-- End Breadcrumbs -->

   <!-- ======= Portfolio Section ======= -->
   

    <section id="portfolio" class="portfolio">
      <div class="container" data-aos="fade-up">
        <div class="row gy-4 mb-4 portfolio-container" data-aos="fade-up" data-aos-delay="200">
          <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-3 col-md-6 portfolio-item filter-app">
            <div class="card">
              <img src="<?php echo e(asset($item->image)); ?>" class="card-img-top" alt="">
              <div class="card-body">
                <h5 class="card-title"><?php echo e($item->name); ?> (<?php echo e($item->gallery->count()); ?>)</h5>
              </div>
              <a class="event-link" href="<?php echo e(route('event-gallery', $item->id)); ?>"></a>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.website', ['pageName' => 'Gallery'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/website/gallery.blade.php ENDPATH**/ ?>