


<?php $__env->startSection('admin-content'); ?>
<main>
    <div class="container-fluid">
        <div class="card my-3">
            <div class="card-header">
                <i class="far fa-envelope"></i>
                Customer Query
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Subject</th>
                                <th>Message</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo $item->email; ?></td>
                                    <td>
                                        <?php if(Str::of($item->subject)->wordCount() > 10): ?>
                                        <?php echo Str::words($item->subject, 10, '...'); ?>

                                        <?php else: ?>
                                        <?php echo e($item->subject); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(Str::of($item->message)->wordCount() > 10): ?>
                                        <?php echo Str::words($item->message, 10, '...'); ?>

                                        <?php else: ?>
                                        <?php echo e($item->message); ?>

                                        <?php endif; ?>
                                    </td>                          
                                    <td>
                                        <?php if(Str::of($item->message)->wordCount() > 10): ?>
                                        <a href="#staticBackdrop<?php echo e($item->id); ?>" class="d-inline btn btn-primary btn-sm b-btn mr-1"  data-toggle="modal" style="text-decoration: none;">
                                            <i class="far fa-eye"></i>
                                        </a>
                                        <div class="modal fade" id="staticBackdrop<?php echo e($item->id); ?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content modal-background">
                                                    <div class="modal-header message-modal-header">
                                                        <h5 class="modal-title" id="staticBackdropLabel">Message</h5>
                                                        <p class="mb-0 ms-auto mt-1"><strong class="text-white">Date: </strong><?php echo e($item->created_at); ?></p>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                    </div>
                                                    <div class="modal-body" style="background: #f2f2f2; padding: 0.5rem 1rem">
                                                        <div class="clearfix">
                                                            <div class="name float-left model-pattern" >Name: <span style="color: #000"><?php echo e($item->name); ?></span></div>
                                                            <div class="email float-right model-pattern" >Email: <span style="color: #000"><?php echo e($item->email); ?></span></div>
                                                        </div>
                                                        <hr class="custom-hr">
                                                        <div style="padding-top: 0; text-align: justify">
                                                            <strong class="message d-block model-pattern">Message: </strong>
                                                            <?php echo $item->message; ?>

                                                        </div>
                                                    </div>
                                                    <div class="modal-footer message-modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <a href="<?php echo e(route('contact.delete', $item->id)); ?>" type="submit" class="d-inline btn btn-danger btn-sm b-btn" onclick="return confirm('Are you sure you want to delete?');"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5">Data Not Found</td>
                                </tr>
                            <?php endif; ?>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', ['pageName'=> 'contact', 'title' => 'All Customer Message'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/admin/query/contact.blade.php ENDPATH**/ ?>