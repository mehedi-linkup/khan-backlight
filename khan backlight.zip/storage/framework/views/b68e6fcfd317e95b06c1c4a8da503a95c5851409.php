

<?php $__env->startSection('admin-content'); ?>

<main>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card my-3">
                    <div class="card-header">
                        <i class="fas fa-edit mr-1"></i>Update Factory Point
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('update.factorypoint', $factorypoint->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6 mb-2">
                                    <label for="title"> Title </label>
                                    <input type="text" name="title" value="<?php echo e($factorypoint->title); ?>" class="form-control form-control-sm mb-2" id="title" placeholder="Enter factory title">
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            
                            <div class="clearfix border-top">
                                <div class="float-md-right mt-2">
                                    <button type="reset" class="btn btn-dark btn-sm">Reset</button>
                                    <button type="submit" class="btn btn-info btn-sm">Update</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-master', ['pageName'=> 'factorypoint', 'title' => 'Add Factory Point'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/admin/factory/factory-point.blade.php ENDPATH**/ ?>