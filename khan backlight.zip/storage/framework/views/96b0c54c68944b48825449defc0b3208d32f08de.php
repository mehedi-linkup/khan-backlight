
<?php $__env->startPush('web-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/toastr.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('web-content'); ?>

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
  <div class="container">

    <ol>
      <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li> Cart </li>
    </ol>
    <h2>Shopping Cart</h2>

  </div>
</section><!-- End Breadcrumbs -->



<section id="cart" class="cart">
    <div class="container" data-aos="fade-up">
      <!-- Feature Tabs -->
      <div class="row" data-aos="fade-up">
        <div class="col-lg-12 mb-1">
            <table class="table table-bordered text-center mb-0">
                <thead class="bg-light font-md text-dark">
                    <tr>
                        <th>Products</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Update</th>
                        <th>Remove</th>
                    </tr>
                </thead>
                <tbody class="align-middle font-sm">
                    <?php $__currentLoopData = $cartItems->sortBy('id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle d-flex">
                            <img src="<?php echo e(asset($item->attributes['image'])); ?>" alt="" style="width: 50px; height: 50px; border-radius: 2px">
                           <span style="align-self: center;padding-left: 10px;font-weight: 600;"> <?php echo e($item->name); ?></span>
                        </td>
                        <td class="align-middle"><?php echo e(number_format($item->price, 2)); ?>/-</td>
                        <form action="<?php echo e(route('cart.update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                        <td class="align-middle">
                            <div class="input-group quantity mx-auto" style="width: 116px;">
                                <div class="input-group-btn">
                                    <button type="button" class="btn btn-sm btn-mod-primary btn-minus" >
                                        <i class="bi bi-dash-lg"></i>
                                    </button>
                                </div>
                                <input name="quantity" type="text" class="form-control form-control-sm bg-mod-secondary text-center" value="<?php echo e($item->quantity); ?>">
                                <div class="input-group-btn">
                                    <button type="button" class="btn btn-sm btn-mod-primary btn-plus">
                                        <i class="bi bi-plus-lg"></i>
                                    </button>
                                </div>
                            </div>
                        </td>
                        <td class="align-middle">Tk <?php echo e($item->price * $item->quantity); ?></td>
                        <td class="align-middle">
                            <button type="submit" class="btn btn-sm btn-mod-primary">Update</button>
                        </td>
                        </form>
                        <td class="align-middle"><a href="<?php echo e(route('cart.remove', $item->id)); ?>" class="btn btn-sm btn-mod-primary"><i class="bi bi-x-lg"></i></a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="col-lg-4 offset-lg-8">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-0 pt-0">
                        <h6 class="font-weight-medium font-sm mb-0">Subtotal</h6>
                        <h6 class="font-weight-medium font-sm mb-0">TK. <?php echo e(\Cart::getTotal()); ?></h6>
                    </div>
                </div>
                <div class="card-footer border-secondary bg-transparent">
                    <div class="d-grid gap-2">
                        
                        <a href="<?php echo e(route('checkout')); ?>" class="btn btn-success my-1 py-2">Proceed To Checkout</a>
                        
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('web-js'); ?>
  <script src="<?php echo e(asset('website/assets/vendor/jquery-3.6.0.min.js')); ?>"></script>
  <script>
      // Product Quantity
      $('.quantity button').on('click', function () {
        var button = $(this);
        var oldValue = button.parent().parent().find('input').val();
        if (button.hasClass('btn-plus')) {
            var newVal = parseFloat(oldValue) + 1;
        } else {
            if (oldValue > 0) {
                var newVal = parseFloat(oldValue) - 1;
            } else {
                newVal = 0;
            }
        }
        button.parent().parent().find('input').val(newVal);
    });
  </script>
  <script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>

  <script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
  <script>
      <?php if(Session::has('success')): ?>
      toastr.options =
      {
          "closeButton" : true,
          "progressBar" : true
      }
      toastr.success("<?php echo e(session('success')); ?>");
      <?php endif; ?>
  
      <?php if(Session::has('error')): ?>
      toastr.options =
      {
          "closeButton" : true,
          "progressBar" : true
      }
              toastr.error("<?php echo e(session('error')); ?>");
      <?php endif; ?>
  </script>
<?php $__env->stopPush(); ?>
  
<?php echo $__env->make('layouts.website', ['pageName' => 'cart'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/website/cart.blade.php ENDPATH**/ ?>