

<?php $__env->startSection('admin-content'); ?>

<main>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card my-3">
                    <div class="card-header">
                        <?php if(@isset($eventData)): ?>
                        <i class="fas fa-edit mr-1"></i>Update Event
                        
                        <?php else: ?>
                        <i class="fas fa-plus mr-1"></i>Add Event
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e((@$eventData) ? route('admin.event.update', $eventData->id) : route('admin.event.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12 mb-2">
                                    <label for="name"> Name <span class="text-danger">*</span> </label>
                                    <input type="text" name="name" value="<?php echo e(@$eventData->name); ?>" class="form-control form-control-sm mb-2" id="name" placeholder="Enter Event Name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12 mb-2">
                                    <label for="image"> Image <span class="text-danger">*</span> </label>
                                    <input type="file" name="image" value="<?php echo e(@$eventData->image); ?>" class="form-control form-control-sm mb-2" id="image" onchange="mainThambUrl(this)">
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <div class="form-group mt-2">
                                        <img class="form-controlo img-thumbnail" src="<?php echo e((@$eventData) ? asset($eventData->image) : asset('uploads/no.png')); ?>" id="mainThmb" style="width: 150px;height: 120px;">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="clearfix border-top">
                                <div class="float-md-right mt-2">
                                    <?php if(@$eventData): ?>
                                    <a href="<?php echo e(route('admin.event')); ?>" class="btn btn-dark btn-sm">Back</a>
                                    <?php else: ?>
                                    <button type="reset" class="btn btn-dark btn-sm">Reset</button>
                                    <?php endif; ?>
                                    <button type="submit" class="btn btn-info btn-sm"><?php echo e((@$eventData)? 'Update':'Create'); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>

            <div class="col-md-12">
                <div class="card my-3">
                    <div class="card-header">
                        <i class="fas fa-list mr-1"></i>
                        Event List
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Image</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td><img src="<?php echo e($item->image); ?>" alt="" height="30px" width="30px"></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.event.edit', $item->id)); ?>" class="btn btn-info btn-mod-info btn-sm"><i class="fas fa-edit"></i></a>
                                            <a href="<?php echo e(route('admin.event.delete', $item->id)); ?>" onclick="return confirm('Are you sure to Delete?')" class="btn btn-danger btn-mod-danger btn-sm"><i class="fas fa-trash"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('admin-js'); ?>
<script>
    function mainThambUrl(input){
      if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function(e){
            $('#mainThmb').attr('src',e.target.result).width(150)
                  .height(120);
        };
        reader.readAsDataURL(input.files[0]);
      }
    }
</script>

<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.admin-master', ['pageName'=> 'event', 'title' => 'Add Event'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/admin/event.blade.php ENDPATH**/ ?>