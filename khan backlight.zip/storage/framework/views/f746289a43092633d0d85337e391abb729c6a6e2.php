

<?php $__env->startPush('admin-css'); ?>
    <link href="<?php echo e(asset('summernote/summernote-bs4.min.css')); ?>" rel="stylesheet">  
<?php $__env->stopPush(); ?>
<?php $__env->startSection('admin-content'); ?>
<main>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="form-area">
                    <h4 class="heading"><i class="fas fa-edit"></i> Edit Sister Concern</h4>
                    <form action="<?php echo e(route('update.sister', $sister->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6 mb-2">
                                <label for="name" class="mb-1"> Title <span class="text-danger">*</span> </label>
                                <input type="text" name="name" class="form-control form-control-sm shadow-none <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" placeholder="Enter sister Name" value="<?php echo e($sister->name); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                                <label for="s_description" class="mb-1">Short Description</label>
                                <textarea name="s_description" class="form-control form-control-sm" id="s_description" rows="3"><?php echo e($sister->s_description); ?></textarea>
                                <?php $__errorArgs = ['s_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                               
                            </div>

                            <div class="col-md-6 mb-2">

                                <label for="image">Image</label>
                                <input class="form-control form-control-sm" id="image" type="file" name="image" onchange="readImgURL(this);">
                                <div class="form-group mt-2" style="margin-bottom: 0">
                                    <img class="img-thumbnail" src="#" id="previewImage" style="width: 160px;height: 130px;">
                                </div>
                            </div>
                        </div>
                        <div class="clearfix border-top">
                            <div class="float-md-right mt-2">
                                <a href="<?php echo e(route('sister')); ?>" class="btn btn-dark btn-sm">Prev</a>
                                <button type="submit" class="btn btn-info btn-sm">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('admin-js'); ?>
<script src="<?php echo e(asset('summernote/summernote-bs4.min.js')); ?>"></script>
<script>
    $('#description').summernote({
        tabsize: 2,
        height: 120
    });

    function readImgURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#previewImage')
                    .attr('src', e.target.result)
                    .width(160)
                    .height(130);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    document.getElementById("previewImage").src="<?php echo e(asset($sister->image)); ?>";
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-master', ['pageName'=> 'sister', 'title' => 'Edit Sister Concern'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/admin/sister/edit.blade.php ENDPATH**/ ?>