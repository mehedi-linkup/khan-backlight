
<?php $__env->startSection('web-content'); ?>

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
  <div class="container">

    <ol>
      <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li> Sister Concern </li>
    </ol>
    <h2>Sister Concerns</h2>

  </div>
</section><!-- End Breadcrumbs -->


    <!-- ======= Sister Concern Section ======= -->
    <section id="services" class="services">

        <div class="container" data-aos="fade-up">  
          <div class="row gy-4">

            <?php $__currentLoopData = $sister; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
              <div class="service-box blue">
                <div class="img-box p-lg-5 pt-lg-0">
                  <img src="<?php echo e(asset($item->image)); ?>" alt="" class="img-fluid rounded">
                </div>
                <h3><?php echo e($item->name); ?></h3>
                <p><?php echo e($item->s_description); ?></p>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
  
        </div>
  
      </section><!-- End Sister Concern Section -->

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/website/sister-concern.blade.php ENDPATH**/ ?>