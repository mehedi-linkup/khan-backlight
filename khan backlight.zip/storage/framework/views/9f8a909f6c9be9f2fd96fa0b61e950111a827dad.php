
<?php $__env->startSection('web-content'); ?>
<?php $__env->startPush('web-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/toastr.min.css')); ?>">
<?php $__env->stopPush(); ?>
<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
  <div class="container">

    <ol>
      <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li> Product Details </li>
    </ol>
    <h2><?php echo e($product->name); ?></h2>

  </div>
</section><!-- End Breadcrumbs -->

 <!-- ======= Portfolio Details Section ======= -->
 <section id="portfolio-details" class="portfolio-details">
    <div class="container">

      <div class="row gy-4">

        <div class="col-lg-6">
          <div class="portfolio-details-slider swiper">
            <div class="swiper-wrapper align-items-center">

              <div class="swiper-slide">
                <img src="<?php echo e(asset($product->image)); ?>" alt="">
              </div>
            </div>

            <div class="swiper-pagination"></div>
          </div>
        </div>

        <div class="col-lg-6">
          <div class="portfolio-description">
            <h2>Product Information</h2>
            <p><strong>Product Name: </strong><?php echo e($product->name); ?></p>
            <h6><strong>Model: </strong> <?php echo e($product->model->name); ?></h6>
            <div>
            <div>
              <strong>Description: </strong>
              <?php echo $product->description; ?>

            </div>
            <form action="<?php echo e(route('cart.store')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="id" value="<?php echo e($product->id); ?>">

            <div class="quantity">

              <div class="mb-2"><strong>Quantity:</strong> </div>
              <div class="input-group quantity me-auto" style="width: 100px;">
                <div class="input-group-btn">
                    <button type="button" class="btn btn-sm btn-mod-primary btn-minus" >
                        <i class="bi bi-dash-lg"></i>
                    </button>
                </div>
                <input type="text" name="quantity" class="form-control form-control-sm bg-mod-secondary text-center" value="1">
                <div class="input-group-btn">
                    <button type="button" class="btn btn-sm btn-mod-primary btn-plus">
                        <i class="bi bi-plus-lg"></i>
                    </button>
                </div>
              </div>
            </div>
            <div class="pt-3 pt-md-4">
                <button type="submit" class="btn button-2 btn-card">Add To Cart</button>
            </div>
            </form>
          </div>
        </div>

      </div>

    </div>
  </section><!-- End Portfolio Details Section -->

</main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('web-js'); ?>
<script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
<script>
    <?php if(Session::has('success')): ?>
    toastr.options =
    {
        "closeButton" : true,
        "progressBar" : true
    }
    toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
    toastr.options =
    {
        "closeButton" : true,
        "progressBar" : true
    }
            toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>
</script>
<script>
    // Product Quantity
    $('.quantity button').on('click', function () {
      var button = $(this);
      var oldValue = button.parent().parent().find('input').val();
      if (button.hasClass('btn-plus')) {
          var newVal = parseFloat(oldValue) + 1;
      } else {
          if (oldValue > 0) {
              var newVal = parseFloat(oldValue) - 1;
          } else {
              newVal = 0;
          }
      }
      button.parent().parent().find('input').val(newVal);
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.website', ['pageName' => 'Product'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mehedi\khan backlight\resources\views/pages/website/product-detail.blade.php ENDPATH**/ ?>